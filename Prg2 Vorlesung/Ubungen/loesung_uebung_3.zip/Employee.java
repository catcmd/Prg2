/**
 * Created by Wolfgang Mühlbauer on 16.03.2016.
 */
public class Employee {

    // ATTRIBUTES
    private String name;
    private float salary;



    // CONSTRUCTORS
    public Employee(String n) {
        name = n;
        salary = 0;
    }

    public Employee(String n, float s) {
        name = n;
        salary = s;
    }


    // METHODS
    public String getName() {
        return name;
    }

    public float getSalary() {
        return salary;
    }


    // Setter: only allows salaries less than 50000 €
    public void setSalary(float s) {
        if (salary <= 50000) {
            salary = s;
        }
    }

    // returns a String representation of the object <name>|<salary>
    public String getInfo() {
        return name + "|" + salary;
    }

}

