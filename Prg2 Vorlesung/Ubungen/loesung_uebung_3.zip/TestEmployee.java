import java.util.Arrays;
import java.util.Scanner;

/**
 * Created by Wolfgang Mühlbauer on 16.03.2016.
 */
public class TestEmployee {

    public static void main(String[] args) {
        // Part 1: create three objects
        Employee e1 = new Employee("Touring");
        Employee e2 = new Employee("Zuse", 4050.30f);
        Employee e3 = new Employee("Zuckerberg", 900);

        // Part 2: collect 3 objects in an array
        Employee[] employees = new Employee[3];
        employees[0] = e1;
        employees[1] = e2;
        employees[2] = e3;
        /* Alternative
        Employee[] employees = {e1, e2, e3};
        */

        // Part 3: ask user for salary of Touring and set salary
        System.out.print("Please enter salary for Touring: ");
        Scanner scanner = new Scanner(System.in);
        float input = scanner.nextFloat();
        e1.setSalary(input);

        // Part 4: compute average salary of all 3 employees (round to integer)
        float sum = 0;
        for (Employee e : employees) {
            sum += e.getSalary();
        }
        int average = Math.round(sum / employees.length);

        System.out.println("Durchschnittsgehalt ist: " + average);


    }

}
