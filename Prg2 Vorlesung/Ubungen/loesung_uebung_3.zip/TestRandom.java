import java.util.Random;

/**
 * Created by Wolfgang Mühlbauer on 31.03.2017.
 */
public class TestRandom {

    public static void main(String[] args) {

        // generate instance/object of class Random that produces pseudorandom sequence of numbers
        Random random = new Random();

        // count frequency of "Kopf"
        int countKopf = 0;

        for (int i = 0; i < 100000; i++) {

            // likelihood of 75% for "Kopf"
            if (random.nextDouble() < 0.75) {
                countKopf++;
            }
        }

        System.out.println("Anzahl Kopf: " + countKopf + "    Anzahl Zahl: " + (100000 - countKopf));

    }
}
